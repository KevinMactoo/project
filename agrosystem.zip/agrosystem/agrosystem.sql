-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 19, 2019 at 08:50 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `agrosystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(100) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_password`) VALUES
(2, 'super_admin', 'super@super'),
(3, 'admin', 'admin@admin');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `cat_id` int(100) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(255) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_name`) VALUES
(1, 'FERTILIZERS'),
(2, 'SEEDS'),
(3, 'EQUIPMENT');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `order_id` int(100) NOT NULL AUTO_INCREMENT,
  `user_email` varchar(255) NOT NULL,
  `user_phone` varchar(255) NOT NULL,
  `user_order` text NOT NULL,
  `user_app` varchar(255) NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_email`, `user_phone`, `user_order`, `user_app`) VALUES
(2, 'test@test.test', '07123456', 'Absorber is a water retainer that, when incorporated into soil or a substrate\r\n50bags\r\nmm/dd/yyyy', 'YES'),
(3, 'client@test.com', '07123456', 'Absorber is a water retainer that, when incorporated into soil or a substrate, absorbs and retains large quantities of water and nutrients\r\n80bags\r\nmm/dd/yyyy', 'YES'),
(5, 'rio@mail.com', '072005XXXX', 'Absorber is a water retainer that, when incorporated into soil or a substrate', 'NO');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `pro_id` int(100) NOT NULL AUTO_INCREMENT,
  `pro_name` varchar(255) NOT NULL,
  `pro_cat` varchar(255) NOT NULL,
  `pro_price` varchar(255) NOT NULL,
  `pro_desc` text NOT NULL,
  `pro_image` text NOT NULL,
  PRIMARY KEY (`pro_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pro_id`, `pro_name`, `pro_cat`, `pro_price`, `pro_desc`, `pro_image`) VALUES
(12, 'NH4)2HPO4 Diammonium phosphate', '1', '7500', 'EcoGrow Plus Neem is our premium soil conditioner.\r\nProviding humeric compounds and fibre to the soil along with macro and micro', 'fert2.jpg'),
(13, 'NH4)2HPO4 Diammonium phosphate', '1', '7500', 'EcoGrow Plus Neem is our premium soil conditioner.\r\nProviding humeric compounds and fibre to the soil along with macro and micro', 'fert2.jpg'),
(14, 'NH4)2HPO4 Diammonium phosphate', '1', '7500', 'EcoGrow Plus Neem is our premium soil conditioner.\r\nProviding humeric compounds and fibre to the soil along with macro and micro', 'fert2.jpg'),
(15, 'NH4)2HPO4 Diammonium phosphate', '1', '7500', 'EcoGrow Plus Neem is our premium soil conditioner.\r\nProviding humeric compounds and fibre to the soil along with macro and micro', 'fert2.jpg'),
(7, 'NH4)2HPO4 Diammonium phosphate', '1', '8000', 'Absorber is a water retainer that, when incorporated into soil or a substrate', 'fert1.jpg'),
(8, 'NH4)2HPO4 Diammonium phosphate', '1', '8000', 'Absorber is a water retainer that, when incorporated into soil or a substrate', 'fert1.jpg'),
(9, 'NH4)2HPO4 Diammonium phosphate', '1', '8000', 'Absorber is a water retainer that, when incorporated into soil or a substrate', 'fert1.jpg'),
(10, 'NH4)2HPO4 Diammonium phosphate', '1', '8000', 'Absorber is a water retainer that, when incorporated into soil or a substrate', 'fert1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(100) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_password`) VALUES
(1, 'super_admin', 'super_pass'),
(2, 'Admin', 'pass_1234'),
(3, 'testone@mail.com', 'pass123'),
(4, 'client@test.com', 'pass1234'),
(5, 'test@test.test', 'pass1234'),
(6, 'rio@mail.com', 'pass1234'),
(7, 'phone@mail.com', 'pass1234');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
