
<!DOCTYPE HTML>
<?php

   include("functions/functions.php");
?>
<html>
<head>
<title>Details</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" href="css/lightbox.css" type="text/css" media="all" />
<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js'></script>
<script src='js/jquery.color-RGBa-patch.js'></script>
<script src='js/example.js'></script>
<script type="text/javascript" src="http://www.dreamtemplate.com/dreamcodes/jquery.min.js"></script>

<script src="js/lightbox.js"></script>
<script>

  jQuery(document).ready(function($) {
      $('a').smoothScroll({
        speed: 1000,
        easing: 'easeInOutCubic'
      });

      $('.showOlderChanges').on('click', function(e){
        $('.changelog .old').slideDown('slow');
        $(this).fadeOut();
        e.preventDefault();
      })
  });

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-2196019-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>
<body>
<div class="header">
	<div class="header-top">
		<div class="wrap">
			<div class="banner-no">
		  		<img style="width:140px;" src="images/logo.png" alt=""/>
		    </div>
			   <div class="nav-wrap">
          <ul class="group" id="example-one">
               <li class="current_page_item"><a href="home.php">Home</a></li>
               
               <li><a href="user_order.php">My Orders</a></li>
               <li><a href="logout.php">Log Out</a></li>
             
              </ul>
        </div>
        <div id="mySidenav" class="sidenav">
<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
<ul>
  <?php getCats();?>
</ul>
</div>
<script>
function openNav() {
 document.getElementById("mySidenav").style.width = "380px";
}

function closeNav() {
 document.getElementById("mySidenav").style.width = "0";
}
</script>
 			<div class="clear"></div>
   		</div>
    </div>
<div class="block">
	<div class="wrap">

        <div class="clear"></div>
   </div>
</div>
</div>
<div class="content">
	<div class="wrap">
		<div class="content-top">
      <div>
        <?php

        include('db.php');
        //session_start();


        if(isset($_GET['pro_id'])){

          $pro_id=$_GET['pro_id'];

        $get_pro="select * from products where pro_id='$pro_id'";
      $run_pro =mysqli_query($con,$get_pro);

      while($row_pro= mysqli_fetch_array($run_pro)){
        $pro_id=$row_pro['pro_id'];
        $pro_name=$row_pro['pro_name'];
        $pro_price=$row_pro['pro_price'];
        $pro_image=$row_pro['pro_image'];
        $pro_cat=$row_pro['pro_cat'];
        $pro_desc=$row_pro['pro_desc'];
        echo"
            <div id='single_product'style='float:left;position:absolute;'>
            <h3>$pro_name</h3>
            <img src='admin/images/$pro_image'width='200' height='230'/>
            <p><b style='color:red;'>Ksh.$pro_price<b/></p>

            <p style='width:25%; color:black;'> $pro_desc</p>
            <b><a href='home.php?pro_id=$pro_id'style='float:left;color:blue'>Go Back</a></b>


                     </div>

        ";
      }
        }


        if(isset($_POST['insert_post'])){
       	 //getting the text data from the fields
       	 $user_email=$_POST['user_email'];
         $user_phone=$_POST['user_phone'];
         $user_order=$_POST['user_order'];
        $pro_order = $_GET['pro_name'];

        
         $user_app = 'NO';



       	$insert_product = "INSERT INTO orders (user_email, user_phone, user_order,user_app) VALUES ('$user_email','$user_phone','$user_order','$user_app')";

       	 if(mysqli_query($con, $insert_product)){

       	 // $insert_pro
       		 echo"<script>alert('Order has been submitted!')</script>";
       		 echo"<script>window.open('home.php','_self')</script>";
       	 }else {

       		 echo "Error: ".$insert_product." <br />". mysqli_error($con);
       	 }
        }





      ?>


      </div>

<div class="content">
	<div class="wrap">
		<div class="">
				<div class="">
				<div class="col span_2_of_3" style="float:right;position:relative;">
				  <div class="contact-form">
				  	<h3>Place an Order</h3>
					    <form action = "" method="post" enctype="multipart/form-data">

						    <div>
						    	<span><label>E-MAIL</label></span>
						    	<span><input type="text" name="user_email" size="50" required></span>
						    </div>
						    <div>
						     	<span><label>MOBILE.NO</label></span>
						    	<span><input type="text" name="user_phone" size="50" required>
						    </div>
						    <div>
						    	<span><label>SUBJECT</label></span>
                  <?php

                          if(isset($_GET['pro_id'])){

                            $pro_id=$_GET['pro_id'];

                          $get_pro="select * from products where pro_id='$pro_id'";
                        $run_pro =mysqli_query($con,$get_pro);

                        while($row_pro= mysqli_fetch_array($run_pro)){
                          $pro_id=$row_pro['pro_id'];
                          $pro_name=$row_pro['pro_name'];

                          echo"

                              <span><h5>ORDER:$pro_name</h5></span>

                                       </div>

                          ";
                        }
                          }
                  ?>
                <div>
                    <span><textarea type="text" name="user_order" size="150" required></textarea>
                    </span>
						    </div>
                <div>
 						   		<span><input type="submit" name="insert_post" value="Submit Order"/></span>
 						  </div>
					    </form>
				  </div>
  				</div>

			  </div>
				<div class="clear"></div>
			</div>
	</div>
</div>

<div class="footer">
	<div class="wrap">
			<div class="footer-top">

				<div class="clear"></div>
			</div>
		</div>
	</div>
<div class="footer-bottom">
	<div class="wrap">

 	</div>
</div>

</body>

</html>
