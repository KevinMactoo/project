<!DOCTYPE HTML>

<?php

require 'db.php';

?>

<?php
 if(isset($_POST['insert_post'])){
	 //getting the text data from the fields
	 $user_name=$_POST['user_name'];
	  $user_password=$_POST['user_password'];


	$insert_product = "INSERT INTO users (user_name, user_password) VALUES ('$user_name','$user_password')";

	 if(mysqli_query($con, $insert_product)){

	 // $insert_pro
		 echo"<script>alert('User has been Created!')</script>";
		 echo"<script>window.open('index.php','_self')</script>";
	 }else {

		 echo "Error: ".$insert_product." <br />". mysqli_error($con);
	 }
 }

?>

<html>
<head>
<title>Register</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js'></script>
<script src='js/jquery.color-RGBa-patch.js'></script>
<script src='js/example.js'></script>
</head>
<body>
<div class="header">
	<div class="header-top">
		<div class="wrap">
			<div class="banner-no">
		  		<img style="width:140px;" src="images/logo.png" alt=""/>
		    </div>
			  <div class="nav-wrap">
					<ul class="group" id="example-one">
                <li><a href="index.php">Home</a></li>
			        </ul>
			  </div>
 			<div class="clear"></div>
   		</div>
    </div>
<div class="block">
	<div class="wrap">

        <div class="clear"></div>
   </div>
</div>
</div>
<div class="content">
	<div class="wrap">
		<div class="content-top">
				<div class="section group">
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h3>Create User Account</h3>
					     <form action="" method="post" enctype="multipart/form-data">
					    	<div>
						    	<span><label>USERNAME</label></span>
						    	<span><input type="text" name="user_name"size="50" required/></span>
						    </div>


						    <div>
						     	<span><label>PASSWORD</label></span>
						    	<span><input type="password" name="user_password" required/></span>
						    </div>
						   <div>
						   		<span><input type="submit" name="insert_post" value="Create Account"/></span>
						  </div>

              <div class="clear"></div>
              <div class="clear"></div>
              <div>
                <p>Click <a href="index.php" style="color:red"><b>Here</b></a> if you have an Account.</p>
              </div>

					    </form>

              <div class="clear"></div>

				  </div>
  				</div>

			  </div>
				<div class="clear"></div>
			</div>
	</div>
</div>
