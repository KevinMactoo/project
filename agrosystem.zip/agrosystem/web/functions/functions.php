<?php



$con =mysqli_connect("localhost","root","","agrosystem");

if(mysqli_connect_errno()){
	echo "Failed to Connect to MySQL:".mysqli_connect_error();

}


//getting the categories
function getCats(){
	$con =mysqli_connect("localhost","root","","agrosystem");
		$get_cats="SELECT products.pro_cat FROM products FULL OUTER JOIN ON products.pro_cat=cat_id ORDER BY categories.cat_id";
	//$get_cats="select * from products where pro_cat='$pro_cat'";
	$run_cats= mysqli_query($con,$get_cats);



	while($row_cats=mysqli_fetch_array($run_cats)){


		$cat_id=$row_cats['pro_cat'];
		$cat_name=$row_cats['pro_name'];


		$pro_id=$row_cats['pro_id'];
		$pro_name=$row_cats['pro_name'];
		$pro_price=$row_cats['pro_price'];
		$pro_image=$row_cats['pro_image'];
		$pro_cat=$row_cats['pro_cat'];
		$pro_desc=$row_cats['pro_desc'];

		echo "
					<div id='single_product'style='float:left;position:absolute;'>
					<a><h3 href='categories.php?cat=$cat_id'>$cat_name></h3></a>

					</div>

		";





	//$cat_id=$row_cats['cat_id'];
	//$cat_name=$row_cats['cat_name'];

		//echo"<li><a href='categories.php?cat=$cat_id'>$cat_name</a></li>";


	}
}
?>
