
<!DOCTYPE HTML>
<?php
   include('session.php');
   include("functions/functions.php");
?>
<html>
<head>
<title>Agrosystems</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" href="css/lightbox.css" type="text/css" media="all" />
<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js'></script>
<script src='js/jquery.color-RGBa-patch.js'></script>
<script src='js/example.js'></script>
<script type="text/javascript" src="http://www.dreamtemplate.com/dreamcodes/jquery.min.js"></script>

<script src="js/lightbox.js"></script>
<script>

  jQuery(document).ready(function($) {
      $('a').smoothScroll({
        speed: 1000,
        easing: 'easeInOutCubic'
      });

      $('.showOlderChanges').on('click', function(e){
        $('.changelog .old').slideDown('slow');
        $(this).fadeOut();
        e.preventDefault();
      })
  });

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-2196019-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>
<body>
<div class="header">
	<div class="header-top">
		<div class="wrap">
			<div class="banner-no">
		  		<img style="width:140px;" src="images/logo.png" alt=""/>
		    </div>
			  <div class="nav-wrap">
					<ul class="group" id="example-one">
			  		   <li class="current_page_item"><a href="home.php">Home</a></li>
              
			  		   <li><a href="user_order.php">My Orders</a></li>
			  		   <li><a href="logout.php">Log Out</a></li>
					   
			        </ul>
			  </div>
        <div id="mySidenav" class="sidenav">
<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
<ul>
  <?php getCats();?>
</ul>
</div>
<script>
function openNav() {
 document.getElementById("mySidenav").style.width = "380px";
}

function closeNav() {
 document.getElementById("mySidenav").style.width = "0";
}
</script>
 			<div class="clear"></div>
   		</div>
    </div>
<div class="block">
	<div class="wrap">

        <div class="clear"></div>
   </div>
</div>
</div>
<div class="w3-content w3-section" style="max-width:100%;max-height:200px;">
  <img class="mySlides w3-animate-top" src="img_rr_01.jpg" style="width:100%">
  <img class="mySlides w3-animate-bottom" src="img_rr_02.jpg" style="width:100%">
  <img class="mySlides w3-animate-top" src="img_rr_03.jpg" style="width:100%">
  <img class="mySlides w3-animate-bottom" src="img_rr_04.jpg" style="width:100%">
</div>

<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}
    x[myIndex-1].style.display = "block";
    setTimeout(carousel, 2500);
}
</script>

<div class="content">
	<div class="wrap">


		<div class="content-top">
			<h3>All Products</h3>
			<?php

$con =mysqli_connect("localhost","root","","agrosystem");
$sql = "SELECT * FROM products";
$result =mysqli_query($con,$sql);

while ($row = mysqli_fetch_array($result)){

	/**echo "<form method='post' action='shop.php?action=add&id=<?php echo $row['movie_id'];?>'>";**/
  $pro_id = $row['pro_id'];
	echo "<div class='col_1_of_4 span_1_of_4'>";
	echo "<div class='imageRow'>";
	echo "<div class='single'>";
	echo "<div class='contact-form'>";
	echo "<img src='admin/images/".$row['pro_image']. "' width='200'height='210'>";
	echo "<h1 class='h-text' style='text:bold;'>".$row['pro_name']."</h1>";
	echo "<p class='h-para'>".$row['pro_desc']."'</p>";
	echo "<p style='color:red;'>Ksh. ".$row['pro_price']."</p>";
	echo "<a href='details.php?pro_id=$pro_id'><span><input type='submit' name='add' style='margin-top:5px;' class='btn btn-default' value='View'></span></a>";
	echo"</div>";
	echo"</div>";
	echo"</div>";
	echo"</div>";
	//echo "</form>";
}



?>
<div class="clear"></div>
			</div>
			</div>
				<div class="clear"></div>


			</div>
<div class="footer">
	<div class="wrap">
			<div class="footer-top">

				<div class="clear"></div>
			</div>
		</div>
	</div>
<div class="footer-bottom">
	<div class="wrap">

 	</div>
</div>

</body>

</html>
