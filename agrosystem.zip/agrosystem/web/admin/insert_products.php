<!DOCTYPE HTML>

<?php

require 'db.php';

?>

<?php
 if(isset($_POST['insert_post'])){
	 //getting the text data from the fields
	 $pro_name=$_POST['pro_name'];
	  $pro_cat=$_POST['pro_cat'];
	    $pro_price=$_POST['pro_price'];
		 $pro_desc=$_POST['pro_desc'];
	 //getting the image from the fields
	  $pro_image=$_FILES['pro_image']['name'];
	  $pro_image_tmp=$_FILES['pro_image']['tmp_name'];

	 move_uploaded_file($pro_image_tmp,"images/$pro_image");

	$insert_product = "INSERT INTO products (pro_name, pro_cat, pro_price, pro_desc, pro_image) VALUES ('$pro_name','$pro_cat','$pro_price','$pro_desc','$pro_image')";

	 if(mysqli_query($con, $insert_product)){

	 // $insert_pro
		 echo"<script>alert('Product Has Been Inserted!')</script>";
		 echo"<script>window.open('insert_products.php','_self')</script>";
	 }else {

		 echo "Error: ".$insert_product." <br />". mysqli_error($con);
	 }
 }

?>

<html>
<head>
<title>Insert Product</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js'></script>
<script src='js/jquery.color-RGBa-patch.js'></script>
<script src='js/example.js'></script>
</head>
<body>
<div class="header">
	<div class="header-top">
		<div class="wrap">
			<div class="banner-no">
		  		<img style="width:140px;" src="images/logo.png" alt=""/>
		    </div>
			 <div class="nav-wrap">
					<ul class="group" id="example-one">
                <li><a href="dashboard.php">Home</a></li>
                <li><a href="insert_products.php">Insert Products</a></li>
                <li><a href="products.php">View All Products</a></li>
                <li><a href="create_cat.php">Create Category</a></li>
                <li><a href="view.php">View Orders</a></li>	
			  	<li><a href="logout.php">Logout</a></li>
			        </ul>
			  </div>
 			<div class="clear"></div>
   		</div>
    </div>
<div class="block">
	<div class="wrap">

        <div class="clear"></div>
   </div>
</div>
</div>
<div class="content">
	<div class="wrap">
		<div class="content-top">
				<div class="section group">
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h3>INSERT PRODUCT</h3>
					     <form action="" method="post" enctype="multipart/form-data">
					    	<div>
						    	<span><label>TITLE</label></span>
						    	<span><input type="text" name="pro_name"size="50" required/></span>
						    </div>
						    <div>
						    	<span><label>PRODUCT CATEGORY</label></span>
						    	<span> <select name="pro_cat" required>
   <option>Select Category</option>
   <?php
   $get_cats="select * from categories";
	$run_cats= mysqli_query($con,$get_cats);

	while($row_cats=mysqli_fetch_array($run_cats)){

		$cat_id=$row_cats['cat_id'];
		$cat_name=$row_cats['cat_name'];

		echo"<option value='$cat_id'>$cat_name</option>";


	}

   ?>
   </select></span>
						    </div>
						    <div>
						     	<span><label>IMAGE</label></span>
						    	<span><input type="file" name="pro_image" required/></span>
						    </div>
						    <div>
						    	<span><label>PRICE</label></span>
						    	<span><input type="text" name="pro_price" required /></span>
						    </div>
							<div>
						    	<span><label>PRODUCT DESCRIPTION</label></span>
						    	<span><textarea name="pro_desc"cols="20" rows="10" ></textarea></span>
						    </div>
						   <div>
						   		<span><input type="submit" name="insert_post" value="Insert Product"/></span>
						  </div>
					    </form>

              <div class="clear"></div>
              <div>
                 <a href= "create_cat.php"><span><input type="submit" name="" value="Create product Category"/></span></a>
             </div>
             <div class="clear"></div>
             <div class="clear"></div>
             <div class="clear"></div>
             <div>
                <a href = "dashboard.php"><span><input type="submit" name="" value="Go to Admin Dashboard"/></span></a>
            </div>
            <div class="clear"></div>
             <div class="clear"></div>
             <div class="clear"></div>
             <div>
                <a href = "view.php"><span><input type="submit" name="" value="View Orders posted"/></span></a>
            </div>
				  </div>
  				</div>

			  </div>
				<div class="clear"></div>
			</div>
	</div>
</div>
