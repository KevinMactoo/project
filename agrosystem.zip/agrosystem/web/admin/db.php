<?php
$servername="localhost";
$serveruser="root";
$serverpass="";
$dbname="agrosystem";
$con=mysqli_connect("$servername","$serveruser","$serverpass","$dbname");
if(mysqli_connect_errno()){
	echo "Failed to Connect to MySQL:".mysqli_connect_error();

}


?>
