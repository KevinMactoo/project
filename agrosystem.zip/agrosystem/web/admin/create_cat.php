<!DOCTYPE HTML>

<?php

require 'db.php';

?>

<?php
 if(isset($_POST['insert_post'])){
	 //getting the text data from the fields
	 $cat_name=$_POST['cat_name'];

	$insert_product = "INSERT INTO categories (cat_name) VALUES ('$cat_name')";

	 if(mysqli_query($con, $insert_product)){

	 // $insert_pro
		 echo"<script>alert('Category Has Been Created!')</script>";
		 echo"<script>window.open('create_cat.php','_self')</script>";
	 }else {

		 echo "Error: ".$insert_product." <br />". mysqli_error($con);
	 }
 }

 

?>

<html>
<head>
<title>Create Category</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js'></script>
<script src='js/jquery.color-RGBa-patch.js'></script>
<script src='js/example.js'></script>
</head>
<body>
<div class="header">
	<div class="header-top">
		<div class="wrap">
			<div class="banner-no">
		  		<img style="width:140px;" src="images/logo.png" alt=""/>
		    </div>
			 <div class="nav-wrap">
					<ul class="group" id="example-one">
                <li><a href="dashboard.php">Home</a></li>
                <li><a href="insert_products.php">Insert Products</a></li>
                <li><a href="create_cat.php">Create Category</a></li>
                <li><a href="view.php">View Orders</a></li>	
			  		   <li><a href="logout.php">Logout</a></li>
			        </ul>
			  </div>
 			<div class="clear"></div>
   		</div>
    </div>
<div class="block">
	<div class="wrap">

        <div class="clear"></div>
   </div>
</div>
</div>
<div class="content">
	<div class="wrap">
		<div class="content-top">
				<div class="section group">
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h3>CREATE CATEGORY</h3>
					     <form action="" method="post" enctype="multipart/form-data">
					    	<div>
						    	<span><label>TITLE</label></span>
						    	<span><input type="text" name="cat_name"size="50" required/></span>
						    </div>

						   <div>
						   		<span><input type="submit" name="insert_post" value="Create Category"/></span>
						  </div>
					    </form>
              <div class="clear"></div>
              <div>
                 <a href= "insert_products.php"><span><input type="submit" name="" value="Insert Products"/></span>
             </div>
             <div class="clear"></div>
             <div class="clear"></div>
             <div class="clear"></div>
             <div>
                <a href = "dashboard.php"><span><input type="submit" name="" value="Go to Admin Dashboard"/></span></a>
            </div>
				  </div>
  				</div>

			  </div>

			</div>
	</div>
</div>
