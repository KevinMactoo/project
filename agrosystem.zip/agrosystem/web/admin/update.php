<?php

require('db.php');



$order_id = $_REQUEST['order_id'];
//$user_app = 'YES';

$query ="UPDATE orders SET user_app = 'YES' WHERE order_id = $order_id" ;


 if(mysqli_query($con, $query)){

	 // $insert_pro
		 echo"<script>alert('Updated!')</script>";
		 echo"<script>window.open('view_super.php','_self')</script>";
	 }else {

		 echo "Error: ".$query." <br />". mysqli_error($con);
	 }
 




//$result =  mysqli_query($con,$query) or die ( mysqli_error());
//header("Location: view_super.php"); 



//if(isset($_POST['update'])) {
            
 //           $user_email = $_REQUEST['user_email'];
   //         $user_app = 'YES';
            
     //       $sql = "UPDATE orders ". "SET user_app = $user_app ". 
       //        "WHERE user_email = $user_email" ;
         //   $retval = mysql_query( $sql, $con);
            
           // if(! $retval ) {
             //  die('Could not update data: ' . mysql_error());
            //}
            //echo "Updated data successfully\n";
            //header("Location: view_super.php");
            
            //mysql_close($con);
         //}else {

         //}




?>