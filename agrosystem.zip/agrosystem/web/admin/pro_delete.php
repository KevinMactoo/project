<?php
require('db.php');
$pro_id=$_REQUEST['pro_id'];


$query = "DELETE FROM products WHERE  pro_id=$pro_id"; 


$result = mysqli_query($con,$query) or die ( mysqli_error());
echo "<script> alert('The Product has been Deleted')</script>";
//echo "<script>window.open('products.php','self')</script>";
header("Location: products.php"); 
?>