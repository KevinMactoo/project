<!DOCTYPE HTML>


<?php
  require  'db.php';
   session_start();

   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form

   	$admin_name = "super_admin";
   	$admin_password = "super@super";

     // $myusername = mysqli_real_escape_string($con,$_POST['user_name']);
     // $mypassword = mysqli_real_escape_string($con,$_POST['user_password']);

      $sql = "SELECT admin_id FROM admin WHERE admin_name = '$admin_name' and admin_password = '$admin_password'";
      $result = mysqli_query($con,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];

      $count = mysqli_num_rows($result);

      // If result matched $myusername and $mypassword, table row must be 1 row

      if($count == 1) {

         $_SESSION['login_user'] = $myusername;

         header("location: view_super.php");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
?>



<html>
<head>
<title>Super Admin</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js'></script>
<script src='js/jquery.color-RGBa-patch.js'></script>
<script src='js/example.js'></script>
</head>
<body>
<div class="header">
	<div class="header-top">
		<div class="wrap">
			<div class="banner-no">
		  		<img style="width:140px;" src="images/logo.png" alt=""/>
		    </div>

			  <div class="nav-wrap">
					<ul class="group" id="example-one">
                <li><a href="index.php">Home</a></li>
			        </ul>
			  </div>
 			<div class="clear"></div>
   		</div>
    </div>
<div class="block">
	<div class="wrap">

        <div class="clear"></div>
   </div>
</div>
</div>
<div class="content">
	<div class="wrap">
		<div class="content-top">
				<div class="section group">
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h3>Super Administrator Sign In</h3>
					     <form action="" method="post" enctype="multipart/form-data">
					    	<div>
						    	<span><label>USERNAME</label></span>
						    	<span><input type="text" name="admin_name"size="50" required/></span>
						    </div>

						    <div>
						     	<span><label>PASSWORD</label></span>
						    	<span><input type="password" name="admin_password" required/></span>
						    </div>

						   <div>
						   		<span><input type="submit" name="insert_post" value="Sign In"/></span>
						  </div>

							<div class="clear"></div>
							<div class="clear"></div>
							
					    </form>

              <div class="clear"></div>

				  </div>
  				</div>

			  </div>
				<div class="clear"></div>
			</div>
	</div>
</div>
