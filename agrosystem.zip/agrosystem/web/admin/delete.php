<?php
require('db.php');
$order_id=$_REQUEST['order_id'];


$query = "DELETE FROM orders WHERE  order_id=$order_id"; 


$result = mysqli_query($con,$query) or die ( mysqli_error());
//echo "<script> alert('The Order has been Deleted')</script>"
//echo "<script>window.open('view_super.php','self')</script>"
header("Location: view_super.php"); 
?>