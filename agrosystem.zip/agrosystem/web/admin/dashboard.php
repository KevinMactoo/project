<!DOCTYPE HTML>

<?php

require 'db.php';
//include ("session.php");

?>

<html>
<head>
<title>Dashboard</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js'></script>
<script src='js/jquery.color-RGBa-patch.js'></script>
<script src='js/example.js'></script>
</head>
<body>
<div class="header">
	<div class="header-top">
		<div class="wrap">
			<div class="banner-no">
		  		<img style="width:140px;" src="images/logo.png" alt=""/>
		    </div>

			  <div class="nav-wrap">
					<ul class="group" id="example-one">
               <li><a href="dashboard.php">Home</a></li>
                <li><a href="insert_products.php">Insert Products</a></li>
                <li><a href="products.php">View All Products</a></li>
                <li><a href="create_cat.php">Create Category</a></li>
			  		   <li><a href="logout.php">Logout</a></li>
			        </ul>
			  </div>
 			<div class="clear"></div>
   		</div>
    </div>
<div class="block">
	<div class="wrap">

        <div class="clear"></div>
   </div>
</div>
</div>
<div class="content">
	<div class="wrap">
		<div class="content-top">
				<div class="section group">
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h3>Administrator Panel</h3>
            				  </div>


  <div class="nav-wrap">
  			<ul class="group" id="example-one">
          <li><b><a href="insert_products.php">INSERT PRODUCT</a></b></li>
          <li><b><a href="create_cat.php">Create Category</a></b></li>
					<li><b><a href="view.php">View Orders</a></b></li>
        </ul>
    </div>
  				</div>

			  </div>
				<div class="clear"></div>
			</div>
	</div>
</div>
