<?php
include_once("db.php");

$sql_query = "SELECT pro_id, pro_name, pro_cat, pro_price, pro_desc, pro_image FROM products";

$resultset = mysqli_query($con, $sql_query) or die("database error:". mysqli_error($con));
$developer_records = array();
while( $rows = mysqli_fetch_assoc($resultset) ) {

$developer_records[] = $rows;
}




if(isset($_POST["export_data"])) {
$filename = "Agrosystem_Order_".date('Ymd') . ".xls";
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=\"$filename\"");
$show_coloumn = false;
if(!empty($developer_records)) {
foreach($developer_records as $record) {
if(!$show_coloumn) {
// display field/column names in first row
echo implode("\t", array_keys($record)) . "\n";
$show_coloumn = true;
}
echo implode("\t", array_values($record)) . "\n";
}
}
exit;
}




?>




<html>
<head>
<title>View Daily Sale</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js'></script>
<script src='js/jquery.color-RGBa-patch.js'></script>
<script src='js/example.js'></script>
</head>
<body>
<div class="header">
	<div class="header-top">
		<div class="wrap">


			  <div class="nav-wrap">
					<ul class="group" id="example-one">
                <li><a href="dashboard.php">Home</a></li>
                <li><a href="insert_products.php">Insert Products</a></li>
                <li><a href="products.php">View All Products</a></li>
                <li><a href="create_cat.php">Create Category</a></li>

			  		   <li><a href="logout.php">Logout</a></li>
			        </ul>
			  </div>
 			<div class="clear"></div>
   		</div>
    </div>
<div class="block">
	<div class="wrap">

        <div class="clear"></div>
   </div>
</div>
</div>
<div class="content">
	<div class="wrap">
		<div class="content-top">
				<div class="section group">
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h3>View Panel</h3>
				  		<div class="clear"></div>
				  		<div class="clear"></div>

				  			<?php
				  			//do something here in code
				  				if (isset($_POST['submit'])){
				  					if(isset($_GET['go'])){
				  						if(preg_match("/[A-Z | a-z+/", $_POST['name'])){
				  							$name= $_POST['name'];
				  							//connect database
				  							include_once("db.php");
				  							$sql = "SELECT order_id, user_email,user_phone,user_order FROM orders ";

				  							$result = mysql_query($sql);

				  							$numrows = mysql_num_rows($result);

				  							echo "<p>"-$numrows -  "results found for " - $letter - " </p>";

				  							while ($row =  mysql_fetch_array($result)){
				  								$order_id = $row['pro_id'];
				  								$user_email = $row['user_email'];
				  								$user_phone = $row['user_phone'];
				  								$user_order = $row['user_order'];

				  							echo "<ul>\n";
				  							echo "<li>" - "<a href=\"view.php?inv_number=$order_id\">" -$user_email - " " - $user_phone - " " -$user_order - "</a></li>\n";
				  							echo "</ul>";

				  							}
				  						}
				  					}

				  				}else{
				  					echo "<p></p>";
				  				}


				  			?>
				  		<div class="clear"></div>


            				  </div>


									  	<div class="container">
<h2>Export Data to Excel with PHP and MySQL</h2>

<form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">
<button style="width: 120px;background-color: #DB9603; margin-top: 50px; font-family: AmbleRegular; font-size: 15px; color: #fff; cursor: pointer; border-radius: 2px;" type="submit" id="export_data" name='export_data' value="Export to excel" class="btn btn-info">Export to excel</button>
</form>
</div>
</div>
<table id="" class="table table-striped table-bordered" style="width:80%; border: 3px solid #ddd; padding: 8px;">
<tr style="border: 1px solid #ddd; padding: 8px;">
<th style="padding-top: 12px; padding-bottom: 12px; text-align: left; color: blue; width: 5%;">PRODUCT ID</th>
<th style="padding-top: 12px; padding-bottom: 12px; text-align: left; color: blue; width: 15%;">PRODUCT NAME</th>
<th style="padding-top: 12px; padding-bottom: 12px; text-align: left; color: blue; width: 15%;">PRODUCT DESCRIPTION</th>
<th style="padding-top: 12px; padding-bottom: 12px; text-align: left; color: blue; width: 15%;">PRODUCT PRICE</th>
<th style="padding-top: 12px; padding-bottom: 12px; text-align: left; color: blue; width: 8%; height: 10px;">PRODUCT IMAGE</th>
<th style="border: 1px solid #ddd; padding-top: 12px; padding-bottom: 12px; text-align: center; color: blue; width: 15%;">DELETE</th>

</tr>
<tbody>
<?php foreach($developer_records as $developer) { ?>
<tr style="height:auto;">
<td style="border: 1px solid #dddddd; text-align: left;background-color: #dddddd;"><?php echo $developer ['pro_id']; ?></td>
<td style="border: 1px solid #dddddd; text-align: left;background-color: #dddddd;"><?php echo $developer ['pro_name']; ?></td>
<td style="border: 1px solid #dddddd; text-align: left;background-color: #dddddd;"><?php echo $developer ['pro_desc']; ?></td>
<td style="border: 1px solid #dddddd; text-align: left;background-color: #dddddd;"><?php echo $developer ['pro_price']; ?></td>
<td style="border: 1px solid #dddddd; text-align: center;background-color: #dddddd;">
<?php
	echo "<img src='images/".$developer['pro_image']. "' width='75'height='75'>";	
		?>
		</td>
<td ><b><a style="color: red; text-align: center;" href="pro_delete.php?pro_id=<?php echo $developer['pro_id']; ?> ">Delete</a></b></td>




</tr>
<?php } ?>
</tbody>
</table>


</div>




  				</div>

			  </div>
				<div class="clear"></div>
			</div>
	</div>
</div>
