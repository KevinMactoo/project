<?php
   include('db.php');
   session_start();

?>
